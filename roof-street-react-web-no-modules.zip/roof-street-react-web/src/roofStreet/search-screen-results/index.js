import React, { useState, useEffect } from "react";
import ArticleList from "../articles";
// import WhatsHappening from "./whats-happening";
import { AiOutlineSearch } from "react-icons/ai";
import { GoGear } from "react-icons/go";
import { useNavigate } from "react-router";
import * as followService from "../services/follows-thunks";
import * as recommendService from "../services/recommends-thunks";

import { useSelector } from "react-redux";
import "./index.css";
import axios from 'axios';

//let orange = null;
// const alpha = require('alphavantage')({ key: 'HKDFJIT4M9Z6J4VN' });
// let dAta = Object.values((alpha.util.polish((await alpha.data.daily(`msft`)))).data)
// console.log(dAta);
// console.log((dAta[98]).close)
let stocksData = "";
const options = {
  method: 'GET',
  url: 'https://latest-stock-price.p.rapidapi.com/any',
  headers: {
    'X-RapidAPI-Key': '426abd5f50msh954d2f0aa9e470ap1c491ejsne42daafa1ddc',
    'X-RapidAPI-Host': 'latest-stock-price.p.rapidapi.com'
  }
};

try {
	const response = await axios.request(options);
  stocksData = response.data;
	console.log(response.data);
} catch (error) {
	console.error(error);
}

//.filter((item) => item.uid === currentUser._id)

const SearchScreenResults = () => {
  const navigate = useNavigate();
  const [follows, setFollows] = useState([]);

  const [recommends, setRecommends] = useState([]);


function check (arr) {
  if (arr.length > 0) {
    return arr;
  } else {
    return [{lastPrice: "Invalid Stock"}];
  }
}

const seeArticles = async () => {

    navigate(`/RoofStreet/details/${window.location.href.split("/")[6]}`);

 };

 const seeSearch = async () => {

  navigate(`/RoofStreet/search`);

};
const fetchFollows = async () => {
  const follows = await followService.getStockFollows(window.location.href.split("/")[6]);
  setFollows(follows);
//  console.log(follows);
};
const fetchRecommends = async () => {
  const recommends = await recommendService.getStockRecommends(window.location.href.split("/")[6]);
  setRecommends(recommends);
  console.log(recommends);
};

useEffect(() => {
  fetchFollows();
  fetchRecommends();
}, []);
 return(
   <>
     <h1>Results</h1>
<br></br>

{/* {banana} */}

<ul className="list-group">
<li className="list-group-item">
  Stock Symbol: 
  {window.location.href.split("/")[6]}
  <br></br>
  Most Recent Stock Price: 
  {(check(stocksData.filter((item) => item.symbol === window.location.href.split("/")[6])))[0].lastPrice}
  <br></br>
  Users Following:
  {follows.length}
  <br></br>
  User Recommendations:
  {recommends.length}
</li>
   </ul>
   <button className="btn btn-primary mt-2"
           onClick={seeArticles}>
     See Articles
   </button>
   <button className="btn btn-primary mt-2"
           onClick={seeSearch}>
     Back to Search
   </button>
   </>
 );
}
export default SearchScreenResults;