import React, { useState, useEffect } from "react";
import { Routes, Route, useLocation } from "react-router";
import NavigationSidebar from "./navigation-sidebar";
import HomeScreen from "./home-screen";
import SearchScreen from "./search-screen";
import DetailsScreen from "./details-screen";
import SearchScreenResults from "./search-screen-results";
import ModerateScreen from "./moderate-screen";
// import ProfileScreen from "./profile-screen";
import WhoToFollowList from "./who-to-follow-list";
import whoReducer from "./reducers/who-reducer";
import articlesReducer from "./reducers/articles-reducer";
import { configureStore } from '@reduxjs/toolkit';
import {Provider} from "react-redux";
import ProfileScreen from "./user/profile-screen";
import ProfileScreenLoggedOut from "./user/profile-screen-loggedout";
import LoginScreen from "./user/login-screen";
import RegisterScreen from "./user/register-screen";
import authReducer from "./reducers/auth-reducer";
const store = configureStore({
  reducer: {who: whoReducer, articles: articlesReducer,    user:  authReducer}});


function RoofStreet() { 


//   const location = useLocation();
// useEffect(() => {
//     console.log('location', location.key); // { key: "3uu089" }
//       const currentUrl = window.location.href;
// console.log(currentUrl);
// const splitUrl = currentUrl.split("/")
// console.log(splitUrl);
// if (splitUrl.length > 5) {
//   console.log("len");
//   if (splitUrl.length[4] === "search") {
//     getStock();
//   }
// }

//     // Fire whatever function you need.
//     //getStock();
//     //sessionStorage.setItem('whatever', state);

// }, [location.key]);
 return (
  <Provider store={store}>
  <div>
     <div className="row">
       <div className="col-2">
         <NavigationSidebar />
       </div>
       <div className="col-10">
       <Routes>
  <Route path="/home" element={<HomeScreen />} />
  <Route path="" element={<HomeScreen />} />
  <Route path="/search" element={<SearchScreen />} />
  {/* <Route path="/bookmarks" element={<BookmarksScreen />} /> */}
  {/* <Route path="/profile" element={<ProfileScreen />} /> */}
  <Route path="/login"    element={<LoginScreen    />} />
           <Route path="/register" element={<RegisterScreen />} />
           <Route path="/profile"  element={<ProfileScreen  />} />
           <Route path="/moderate"  element={<ModerateScreen  />} />





           <Route
  // this path will match URLs like
  // - /teams/hotspur
  // - /teams/real
  path="/profile/:uid"
  // the matching param will be available to the loader
  // loader={({ params }) => {
  //   console.log(params.uid); // "hotspur"
  // }}
  // and the action
  action={({ params }) => {}}
  element={<ProfileScreenLoggedOut />}
/>

{/* <Route

  path="/search/:ticker"

  action={({ params }) => {}}
  element={<SearchScreenResults />}
/> */}
<Route
  path="/search/:ticker"
  element={<SearchScreenResults />} />

<Route
  path="/details/:ticker"
  element={<DetailsScreen />} />






</Routes>
{/* <ArticleList/> */}
       </div>
       {/* <div className="col-3">
       <WhoToFollowList />
       
       </div> */}
     </div>
   </div>
 </Provider>

 );
}
export default RoofStreet;