import React, {useEffect} from "react";
import {useDispatch, useSelector} from "react-redux";
import ArticleItem from "./article-item";
import {findArticlesThunk} from "../services/articles-thunks";

const ArticleList = () => {
  const {articles, loading} = useSelector(state => state.articles)
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(findArticlesThunk())
  }, [])
 
 return(
   <ul className="list-group">
         { loading &&
       <li className="list-group-item">
         Loading...
       </li>
     }

     {
       articles.map(article =>
         <ArticleItem
           key={article._id} article={article}/> )
     }
   </ul>
   
 );
};
export default ArticleList;