import {useDispatch} from "react-redux";
import {createArticle, deleteArticle}
 from "../reducers/articles-reducer";
import {BsFillPatchCheckFill} from "react-icons/bs";
import {SlBubble} from "react-icons/sl";
import {PiArrowsClockwiseBold} from "react-icons/pi";
import {AiFillHeart, AiOutlineDislike} from "react-icons/ai";
import {FiShare} from "react-icons/fi";
import {AiOutlineClose} from "react-icons/ai";
import { updateArticleThunk } from "../services/articles-thunks";
// import { useDispatch } from "react-redux";

//...
const ArticleStats = (
  {


article = {
  "title": "this is a title",
  "userName": "SpaceX",        //fix to force login
  "likes": 0,
  "uid": "apple",                //fix to force login
  "body": "whats???Happen??ing"
}

}
) => {
//...






const dispatch = useDispatch();
const deleteArticleHandler = (id) => {
  dispatch(deleteArticle(id));
}
return(
 <div>
    {/* <div className="row">
    <div className="col-10"> */}
       <div>
        {/* <SlBubble className="me-3"/> {article.replies}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <PiArrowsClockwiseBold className="me-3"/> {article.rearticles}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; */}
         <AiFillHeart className="me-3" onClick={() =>
    dispatch(updateArticleThunk({ ...article, likes: article.likes + 1 }))
  }/> {article.likes}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

{/* <AiOutlineDislike className="me-3" onClick={() =>
    dispatch(updatearticleThunk({ ...article, dislikes: article.dislikes + 1 }))
  }/> {article.dislikes}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; */}

          {/* <FiShare className="me-3"/> */}
          </div>
        {/* <div>
          <i className="bi bi-x-lg float-end"
            onClick={() => deletearticleHandler(article._id)}></i>
        </div> */}
      {/* </div>

    </div> */}
  </div>


 //...







 )
}
export default ArticleStats;