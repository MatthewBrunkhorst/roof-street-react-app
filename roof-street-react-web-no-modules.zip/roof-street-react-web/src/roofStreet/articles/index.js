import React, {useEffect} from "react";
import {useDispatch, useSelector} from "react-redux";
import ArticleItem
  from "./article-item";
import {findArticlesThunk} from "../services/articles-thunks";

const ArticleSummaryList = () => {
  const {articles, loading} = useSelector(state => state.articles)
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(findArticlesThunk())
  }, [])
  let { currentUser } = useSelector((state) => state.user);

// console.log(articles.map(article =>
//   <articleItem
//     key={article._id} article={article}/>).filter((item) => item.uid === currentUser._id));
if (currentUser == null) {
  currentUser = {role: "wrong"};
}




 return(
   <ul className="list-group">
         { loading &&
       <li className="list-group-item">
         Loading...
       </li>
     }

     {(currentUser.role != "JOURNALIST") &&
       articles.map(article =>
         <ArticleItem
           key={article._id} article={article}/> ).slice(-3).reverse()
     }
     {currentUser.role == "JOURNALIST"  &&
       articles.filter((item) => item.uid === currentUser._id).map(article =>
         <ArticleItem
           key={article._id} article={article}/> ).slice(-3).reverse()
     }
   </ul>
   
 );
};
export default ArticleSummaryList;