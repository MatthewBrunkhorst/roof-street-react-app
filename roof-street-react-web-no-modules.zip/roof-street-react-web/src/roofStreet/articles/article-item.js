import {useDispatch, useSelector} from "react-redux";
import {createArticle, deleteArticle}
 from "../reducers/articles-reducer";
 import {deleteArticleThunk} from "../services/articles-thunks";
import {BsFillPatchCheckFill} from "react-icons/bs";
import {SlBubble} from "react-icons/sl";
import {PiArrowsClockwiseBold} from "react-icons/pi";
import {AiFillHeart} from "react-icons/ai";
import {FiShare} from "react-icons/fi";
import {AiOutlineClose} from "react-icons/ai";
import ArticleStats from "./article-stats";
import { useNavigate } from "react-router";
import { specificProfileThunk, logoutThunk, updateUserThunk, deleteUserThunk}
  from "../services/auth-thunks";


//...
const ArticleItem = (
  {


article = {
  "title": "this is a title",
  "userName": "SpaceX",        //fix to force login
  "likes": 0,
  "uid": "apple",                //fix to force login
  "body": "whats???Happen??ing"
}

}
) => {
//...
let { currentUser } = useSelector((state) => state.user);
const navigate = useNavigate();
if (currentUser == null) {
  currentUser = {"_id" : "wrong", "role" : "wrong"}
}
console.log(currentUser.role);


const goToUser = async (userID) => {
  try {
    await dispatch(specificProfileThunk( userID ));
    navigate(`/RoofStreet/profile/${userID}`);
  } catch (e) {
    alert(e);
  }
 };
 const goToStock = async (stock) => {

    navigate(`/RoofStreet/details/${stock}`);
 };

const dispatch = useDispatch();
const deleteArticleHandler = (id) => {
  dispatch(deleteArticleThunk(id));
}
return(
 <li className="list-group-item">
    <div className="row">
      <div className="col-auto">
      </div>
      <div className="col-10">
      <div>
        {(currentUser._id == article.uid || currentUser.role == "ADMIN") && <AiOutlineClose className="me-3 float-end"
            onClick={() => deleteArticleHandler(article._id)}></AiOutlineClose>}
            
        <span onClick={() => goToUser(article.uid)}>By {article.userName} </span>
            </div>
       <span onClick={() => goToUser(article.uid)}><h4>{article.title}</h4> </span>
      <span onClick={() => goToStock(article.stock)}>Stock: {article.stock} </span>
      <li className="list-group-item"><div>{article.body}</div></li>
       {/* <ArticleStats
           key={article._id} article={article}/>  */}
      </div>

    </div>
  </li>


 //...






 )
}
export default ArticleItem;