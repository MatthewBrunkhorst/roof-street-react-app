import React, {useEffect} from "react";
import {useDispatch, useSelector} from "react-redux";
import ArticleItem
  from "../articles/article-item";
import {findArticlesThunk} from "../services/articles-thunks";
import "./index.css";
function ModerateScreen() {
  const {articles, loading} = useSelector(state => state.articles)
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(findArticlesThunk())
  }, [])
 return(
   <>
     

<h1>Delete Posts</h1>
<ul className="list-group">
{articles.map(article =>
         <ArticleItem
           key={article._id} article={article}/> )}
</ul>

   </>
 );
}
export default ModerateScreen;