import React, { useState } from "react";
import { useNavigate } from "react-router";
import { useDispatch } from "react-redux";
import { loginThunk, specificProfileThunk } from "../services/auth-thunks";
function LoginScreen() {
 const [username, setUsername] = useState("");
 const [password, setPassword] = useState("");
 const navigate = useNavigate();
 const dispatch = useDispatch();
 const handleLogin = async () => {
  try {
    await dispatch(loginThunk({ username, password }));
    navigate("/RoofStreet/profile");
  } catch (e) {
    alert(e);
  }
 };
//  const handleBob = async () => {
//   try {
//     await dispatch(specificProfileThunk( "64de656c507455a21764a362" ));
//     navigate("/profile/64de656c507455a21764a362");
//   } catch (e) {
//     alert(e);
//   }
//  };
 return (
  <div>
   <h1>Login</h1>
   <div className="mt-2">
    <label>Username</label>
    <input className="form-control" type="text" value={username}
     onChange={(event) => setUsername(event.target.value)}/>
   </div>
   <div className="mt-2">
     <label>Password</label>
     <input className="form-control" type="password" value={password}
       onChange={(event) => setPassword(event.target.value)}/>
   </div>
   <button className="btn btn-primary mt-2"
           onClick={handleLogin}>
     Login
   </button>
   {/* <button className="btn btn-primary mt-2"
           onClick={handleBob}>
     Bob
   </button> */}
  </div>
 );

}
export default LoginScreen;