import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router";
import { profileThunk, logoutThunk, updateUserThunk, deleteUserThunk}
  from "../services/auth-thunks";
function ProfileScreen() {
 const { currentUser } = useSelector((state) => state.user);
console.log(currentUser);
 const [ profile, setProfile ] = useState(currentUser);
 const dispatch = useDispatch();
 const navigate = useNavigate();
 const save = async () => { await dispatch(updateUserThunk(profile)); }; //Note: Check if keywords "async" and "await" are actually necessary here and in next function
 const funcForUseEffect = async () => { 
  const { payload } = await dispatch(profileThunk());
  setProfile(currentUser);
  
  
};

 useEffect(() => {

   //funcForUseEffect();              //Literally don't know what this was doing, everything works fine without it, may have been doing something but appears to have just caused problems
 }, []);
 return (
  <div>
   <h1>Your Personal Information</h1>
   {profile && (<div>
     <div>
      <label>First Name</label>
      <input type="text" value={profile.firstName}
       onChange={(event) => {
        const newProfile = {
         ...profile, firstName: event.target.value,
        };
        setProfile(newProfile);
       }}/>
     </div>
     <div>
      <label>Last Name</label>
      <input type="text" value={profile.lastName}
       onChange={(event) => {
        const newProfile = {
         ...profile, lastName: event.target.value,
        };
        setProfile(newProfile);
       }}/>
     </div>
     <div>
      <label>Username</label>
      <input type="text" value={profile.username}
       onChange={(event) => {
        const newProfile = {
         ...profile, username: event.target.value,
        };
        setProfile(newProfile);
       }}/>
     </div>
     <div>
      <label>Password</label>
      <input type="password" value={profile.password}
       onChange={(event) => {
        const newProfile = {
         ...profile, password: event.target.value,
        };
        setProfile(newProfile);
       }}/>
     </div>
     </div>
   )}
   <button className="btn btn-primary mt-2"
    onClick={() => {
      dispatch(logoutThunk());
      navigate("/RoofStreet/login");
    }}>                   Logout</button>
   <button className="btn btn-primary mt-2" onClick={save}>Save  </button>
   <button className="btn btn-primary mt-2"
    onClick={() => {
      dispatch(deleteUserThunk(profile));
      dispatch(logoutThunk());
      navigate("/RoofStreet/home");
    }}>                   Delete Account</button>
  </div> );
}
export default ProfileScreen;