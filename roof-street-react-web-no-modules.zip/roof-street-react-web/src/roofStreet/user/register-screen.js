import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import { register, updateUserThunk} from "../services/auth-thunks";
function RegisterScreen() {
 const [username, setUsername] = useState("");
 const [password, setPassword] = useState("");
 const [firstName, setFirstName] = useState("");
 const [lastName, setLastName] = useState("");
 const [role, setRole] = useState("");
//  const [_id, set_id] = useState("");
 const navigate = useNavigate();
 const dispatch = useDispatch();
 const { currentUser } = useSelector((state) => state.user); //
 const [ profile, setProfile ] = useState(currentUser); //
 const handleRegister = async () => {
  console.log({ username, password, firstName, lastName, role});
  try {
    await dispatch(register({ username, password, firstName, lastName, role}));
    
    navigate("/RoofStreet/profile");
  } catch (e) {
    alert(e);
  }
  setProfile(currentUser);
  await dispatch(updateUserThunk(profile)); 
 };

 return (
  <div>
   <h1>Create Account</h1>
   <div className="mt-2">
    <label>Username</label>
    <input className="form-control" type="text" value={username}
     onChange={(event) => setUsername(event.target.value)}/>
   </div>
   <div className="mt-2">
     <label>Password</label>
     <input className="form-control" type="password" value={password}
       onChange={(event) => setPassword(event.target.value)}/>
   </div>
   <div className="mt-2">
    <label>First Name</label>
    <input className="form-control" type="text" value={firstName}
     onChange={(event) => setFirstName(event.target.value)}/>
   </div>
   <div className="mt-2">
     <label>Last Name</label>
     <input className="form-control" type="text" value={lastName}
       onChange={(event) => setLastName(event.target.value)}/>
   </div>
   <br></br>
   <h4>Role</h4>
   <input type="radio" value="ADMIN"
      name="radio-role" id="radio-admin" onChange={(event) => setRole(event.target.value)}/>
<label htmlFor="radio-admin">Admin</label><br/>
<input type="radio" value="JOURNALIST"
      name="radio-role" id="radio-journalist" onChange={(event) => setRole(event.target.value)}/>
<label htmlFor="radio-journalist">Journalist</label><br/>
<input type="radio" value="READER"
      name="radio-role" id="radio-reader" onChange={(event) => setRole(event.target.value)}/>
<label htmlFor="radio-reader">Reader</label><br/>
   {/* <div className="mt-2">
     <label>User ID</label>
     <input className="form-control" type="text" value={_id}
       onChange={(event) => set_id(event.target.value)}/>
   </div> */}
   <br></br>
   <button className="btn btn-primary mt-2"
           onClick={handleRegister}>
     Register
   </button>
  </div>
 );

}
export default RegisterScreen;