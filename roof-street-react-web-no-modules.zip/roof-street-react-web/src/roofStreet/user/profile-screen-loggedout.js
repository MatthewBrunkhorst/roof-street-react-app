import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate, useParams } from "react-router";
import { profileThunk, logoutThunk, updateUserThunk, deleteUserThunk, specificProfileThunk}
  from "../services/auth-thunks";
import ArticleItem
  from "../articles/article-item";
  import * as followService from "../services/follows-thunks";
import * as recommendService from "../services/recommends-thunks";
import {findArticlesThunk} from "../services/articles-thunks";
const ProfileScreen = () => {



  const [follows, setFollows] = useState([]);

  const [recommends, setRecommends] = useState([]);


  const fetchFollows = async () => {
    const follows = await followService.getUserFollows(window.location.href.split("/")[6]);
    setFollows(follows);
  //  console.log(follows);
  };
  const fetchRecommends = async () => {
    const recommends = await recommendService.getUserRecommends(window.location.href.split("/")[6]);
    setRecommends(recommends);
    console.log(recommends);
  };



 const { viewedUser } = useSelector((state) => state.user);
 const dispatch = useDispatch();
 const navigate = useNavigate();
// console.log(viewedUser);
const uid = useParams().uid
 const [ profile, setProfile ] = useState(viewedUser);
//console.log(profile);


 const funcForUseEffect = async () => {  //This function sets the value of the profile variable, but it takes a minute.  If it is just run once, it doesn't work in time?
  const { payload } = await dispatch(specificProfileThunk(uid));
//  console.log(payload);
  setProfile(payload);
  console.log("hi?")
  
};
// if(profile == null) { //This rerenders? the page until the above function works?
//   funcForUseEffect();
// }

 const save = async () => { await dispatch(updateUserThunk(profile)); }; //Note: Check if keywords "async" and "await" are actually necessary here and in next function
  const {articles, loading} = useSelector(state => state.articles)
 useEffect(() => {
  dispatch(findArticlesThunk())
  fetchFollows();
  fetchRecommends();
   funcForUseEffect();              //Literally don't know what this was doing, everything works fine without it, may have been doing something but appears to have just caused problems
 }, []);
 const goToStock = async (stock) => {

  navigate(`/RoofStreet/details/${stock}`);
};
 return (
  <div>
    {profile &&
   <div><h1>{profile.firstName}'s Profile</h1>
   {profile && (<div>
     <div>
      First Name: {profile.firstName}
     </div>
     <div>
      Last Name: {profile.lastName}
     </div></div>
   )}
   <br></br>
   <h2>Recent Articles:</h2>
      <ul className="list-group">
     {
       articles.filter((item) => item.uid === uid).map(article =>
         <ArticleItem
           key={article._id} article={article}/> ).slice(-3).reverse()
     }
     </ul>
     <br></br>
     <h4>Stocks {profile.firstName} Recommends:</h4> {recommends.map(rec => <><span onClick={() => goToStock(rec.stock)}>{rec.stock} </span><br></br></>)}
     <br></br>
     <h4>{profile.firstName}'s Followed Stocks:</h4>{follows.map(flw => <><span onClick={() => goToStock(flw.stock)}>{flw.stock} </span><br></br></>)}
     
     </div>
}
  </div> );
}
export default ProfileScreen;