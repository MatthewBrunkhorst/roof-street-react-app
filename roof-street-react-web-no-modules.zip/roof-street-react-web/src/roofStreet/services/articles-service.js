import axios from 'axios';
const ARTICLES_API = 'http://localhost:4000/api/articles';
export const createArticle = async (article) => {
  const response = await axios.post(ARTICLES_API, article)
  return response.data;
 }
 
export const findArticles = async () => {
  const response = await axios.get(ARTICLES_API);
  const articles = response.data;
  return articles;
 }
 
 export const deleteArticle = async (aid) => {
  const response = await axios.delete(`${ARTICLES_API}/${aid}`)
  return response.data
}

export const updateArticle = async (article) => {
  const response = await axios
    .put(`${ARTICLES_API}/${article._id}`, article);
  return article;
}
