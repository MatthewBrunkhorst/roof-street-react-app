import { createAsyncThunk } from "@reduxjs/toolkit";
import * as service from "./follows-service";
import axios from "axios";
const api = axios.create({
  withCredentials: true,
});

export const findFollowsThunk = createAsyncThunk(
 "follows/findFollows",
 async () => await service.findFollows()
);
export const deleteFollowThunk = createAsyncThunk(
    'follows/deleteFollow',
    async (followId) => {
      await service.deleteFollow(followId)
      return followId
  });

  export const createFollowThunk = createAsyncThunk(
    'follows/createFollow',
    async (follow) => {
      const newFollow = await service.createFollow(follow)
      return newFollow
  });

  export const updateFollowThunk =
  createAsyncThunk(
    'follows/updateFollow',
    async (follow) =>
      await service.updateFollow(follow)
);

  
export const getStockFollows = async (stock) => {
  const response = await api.get(
    `http://localhost:4000/api/stocks/follows/${stock}`
  );
  return response.data;
};

export const getUserFollows = async (stock) => {
  const response = await api.get(
    `http://localhost:4000/api/users/follows/${stock}`
  );
  return response.data;
};