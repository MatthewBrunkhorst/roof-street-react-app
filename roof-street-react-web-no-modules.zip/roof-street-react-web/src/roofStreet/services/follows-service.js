import axios from 'axios';
const ARTICLES_API = 'http://localhost:4000/api/follows';
export const createFollow = async (follow) => {
  console.log(follow);
  const response = await axios.post(ARTICLES_API, follow)

  return response.data;
 }
 
export const findFollows = async () => {
  const response = await axios.get(ARTICLES_API);
  const follows = response.data;
  return follows;
 }
 
 export const deleteFollow = async (aid) => {
  const response = await axios.delete(`${ARTICLES_API}/${aid}`)
  return response.data
}

export const updateFollow = async (follow) => {
  const response = await axios
    .put(`${ARTICLES_API}/${follow._id}`, follow);
  return follow;
}
