import { createAsyncThunk } from "@reduxjs/toolkit";
import * as service from "./articles-service";
import axios from "axios";
const api = axios.create({
  withCredentials: true,
});

export const findArticlesThunk = createAsyncThunk(
 "articles/findArticles",
 async () => await service.findArticles()
);
export const deleteArticleThunk = createAsyncThunk(
    'articles/deleteArticle',
    async (articleId) => {
      await service.deleteArticle(articleId)
      return articleId
  });

  export const createArticleThunk = createAsyncThunk(
    'articles/createArticle',
    async (article) => {
      const newArticle = await service.createArticle(article)
      return newArticle
  });

  export const updateArticleThunk =
  createAsyncThunk(
    'articles/updateArticle',
    async (article) =>
      await service.updateArticle(article)
);

  
export const getStockArticles = async (stock) => {
  const response = await api.get(
    `http://localhost:4000/api/stocks/${stock}`
  );
  return response.data;
};