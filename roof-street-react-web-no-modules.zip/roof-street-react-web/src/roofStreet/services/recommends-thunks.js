import { createAsyncThunk } from "@reduxjs/toolkit";
import * as service from "./recommends-service";
import axios from "axios";
const api = axios.create({
  withCredentials: true,
});

export const findRecommendsThunk = createAsyncThunk(
 "recommends/findRecommends",
 async () => await service.findRecommends()
);
export const deleteRecommendThunk = createAsyncThunk(
    'recommends/deleteRecommend',
    async (recommendId) => {
      await service.deleteRecommend(recommendId)
      return recommendId
  });

  export const createRecommendThunk = createAsyncThunk(
    'recommends/createRecommend',
    async (recommend) => {
      const newRecommend = await service.createRecommend(recommend)
      return newRecommend
  });

  export const updateRecommendThunk =
  createAsyncThunk(
    'recommends/updateRecommend',
    async (recommend) =>
      await service.updateRecommend(recommend)
);

  
export const getStockRecommends = async (stock) => {
  const response = await api.get(
    `http://localhost:4000/api/stocks/recommends/${stock}`
  );
  return response.data;
};

export const getUserRecommends = async (uid) => {
  const response = await api.get(
    `http://localhost:4000/api/users/recommends/${uid}`
  );
  return response.data;
};