import axios from 'axios';
const ARTICLES_API = 'http://localhost:4000/api/recommends';
export const createRecommend = async (recommend) => {
  console.log(recommend);
  const response = await axios.post(ARTICLES_API, recommend)

  return response.data;
 }
 
export const findRecommends = async () => {
  const response = await axios.get(ARTICLES_API);
  const recommends = response.data;
  return recommends;
 }
 
 export const deleteRecommend = async (aid) => {
  const response = await axios.delete(`${ARTICLES_API}/${aid}`)
  return response.data
}

export const updateRecommend = async (recommend) => {
  const response = await axios
    .put(`${ARTICLES_API}/${recommend._id}`, recommend);
  return recommend;
}
