import { createAsyncThunk } from "@reduxjs/toolkit";
import * as authService from "./auth-service";


export const loginThunk = createAsyncThunk(
 "user/login", async (credentials) => {
   const user = await authService.login(credentials);
   return user;
 }
);
export const profileThunk = createAsyncThunk(
  "auth/profile", async () => {
  const response = authService.profile();
  console.log(response);
  return response.data;
 });
 export const logoutThunk = createAsyncThunk(
  "auth/logout", async () => {
  return await authService.logout();
 });
 export const updateUserThunk = createAsyncThunk(
  "user/updateUser", async (user) => {
    await authService.updateUser(user);
    return user;
 });
 export const register = createAsyncThunk(
  "user/register", async (credentials) => {
    const user = await authService.register(credentials);
    return user;
  }
 );
 
 export const deleteUserThunk = createAsyncThunk(
  'user/deleteUser',
  async (user) => {
    await authService.deleteUser(user)
    return user
});

export const specificProfileThunk = createAsyncThunk(
  "auth/profile", async (uid) => {
  const response = await authService.specificProfile(uid);
  console.log(response);
  return response.data;
 });
// export const createTuitThunk = createAsyncThunk(
//   'tuits/createTuit',
//   async (tuit) => {
//     const newTuit = await service.createTuit(tuit)
//     return newTuit
// });