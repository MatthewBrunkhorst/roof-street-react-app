import React from "react";
import { Link, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
const NavigationSidebar = () => {
 const { pathname } = useLocation();
 const [ignore, active] = pathname.split("/");
 const { currentUser } = useSelector((state) => state.user);
 let role = "NONE";
 if (currentUser != null) {
  role = currentUser.role
 }
 return (
   <div className="list-group">
     <Link to={"/RoofStreet/home "} className={`list-group-item
                ${active === "home" || active == null ? "active" : ""}`}><i className="fa-solid fa-house"></i> Home</Link>
     <Link to={"/RoofStreet/search "} className={`list-group-item
                ${active === "search" ? "active" : ""}`}><i className="fa-solid fa-magnifying-glass"></i> Search</Link>
      {role == "ADMIN" &&      <Link to={"/RoofStreet/moderate "} className={`list-group-item
                ${active === "moderate" || active == null ? "active" : ""}`}><i className="fa-solid fa-hammer"></i> Moderate</Link>}
      {!currentUser &&      <Link to={"/RoofStreet/login "} className={`list-group-item
                ${active === "login" || active == null ? "active" : ""}`}><i className="fa-regular fa-user"></i> Login</Link>}
      {!currentUser &&      <Link to={"/RoofStreet/register "} className={`list-group-item
                ${active === "register" || active == null ? "active" : ""}`}><i className="fa-regular fa-user"></i> Register</Link>}
      {currentUser &&      <Link to={"/RoofStreet/profile "} className={`list-group-item
                ${active === "profile" || active == null ? "active" : ""}`}><i className="fa-solid fa-user"></i> Profile</Link>}
   </div>
 );
};
export default NavigationSidebar;