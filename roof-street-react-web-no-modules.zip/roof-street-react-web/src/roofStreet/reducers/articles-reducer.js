import { createSlice } from "@reduxjs/toolkit";
import articles from './articles.json';
import {updateArticleThunk, createArticleThunk, deleteArticleThunk, findArticlesThunk} from "../services/articles-thunks";
const initialState = {
   articles: [],
   loading: false
}


const currentUser = {
 "userName": "NASA",
 "handle": "@nasa",
 "image": "nasa.png",
};

const templateArticle = {
 ...currentUser,
 "topic": "Space",
 "time": "2h",
 "liked": false,
 "replies": 0,
 "rearticles": 0,
 "likes": 0,
}

const articlesSlice = createSlice({
 name: 'articles',







 initialState,
 extraReducers: {
   [findArticlesThunk.pending]:
      (state) => {
         state.loading = true
         state.articles = [] },
   [findArticlesThunk.fulfilled]:
      (state, { payload }) => {
         state.loading = false
         state.articles = payload },
   [findArticlesThunk.rejected]:
      (state, action) => {
         state.loading = false
         state.error = action.error
   },
   [deleteArticleThunk.fulfilled] :
   (state, { payload }) => {
   state.loading = false
   state.articles = state.articles .filter(t => t._id !== payload)
 },
 [createArticleThunk.fulfilled]:
      (state, { payload }) => {
        state.loading = false
        state.articles.push(payload)
    },
    [updateArticleThunk.fulfilled]:
    (state, { payload }) => {
      state.loading = false
      const articleNdx = state.articles.findIndex((t) => t._id === payload._id)
      state.articles[articleNdx] = { ...state.articles[articleNdx], ...payload }
    }
  

 },
 reducers: { }










//  initialState: { articles: articles },
//  reducers: {
//     deleteArticle(state, action) {
//         const index = state.articles
//            .findIndex(article =>
//               article._id === action.payload);
//         state.articles.splice(index, 1);
//       },
   
//    createArticle(state, action) {
//      state.articles.unshift({
//        ...action.payload,
//        ...templateArticle,
//        _id: (new Date()).getTime(),
//     //    title: "test",
//      })
//    }
//  }
});

export const {createArticle, deleteArticle} = articlesSlice.actions;
export default articlesSlice.reducer;