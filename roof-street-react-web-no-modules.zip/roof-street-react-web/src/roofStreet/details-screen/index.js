import React, { useState, useEffect } from "react";
import ArticleList from "../articles";
// import WhatsHappening from "./whats-happening";
import { AiOutlineSearch } from "react-icons/ai";
import { GoGear } from "react-icons/go";
import * as service from "../services/articles-thunks";
import * as followService from "../services/follows-thunks";
import * as recommendService from "../services/recommends-thunks";
import { useSelector, useDispatch } from "react-redux";
import "./index.css";
import axios from 'axios';
import ArticleItem
  from "../articles/article-item";

let stocksData = "";
const options = {
  method: 'GET',
  url: 'https://latest-stock-price.p.rapidapi.com/any',
  headers: {
    'X-RapidAPI-Key': '426abd5f50msh954d2f0aa9e470ap1c491ejsne42daafa1ddc',
    'X-RapidAPI-Host': 'latest-stock-price.p.rapidapi.com'
  }
};

try {
	const response = await axios.request(options);
  stocksData = response.data;
	console.log(response.data);
} catch (error) {
	console.error(error);
}

const DetailsScreen = () => {
  const dispatch = useDispatch();
  let { currentUser } = useSelector((state) => state.user);

  function check (arr) {
    if (arr.length > 0) {
      return arr;
    } else {
      return [{lastPrice: "Invalid Stock"}];
    }
  }

  const [articles, setArticles] = useState([]);
  const [follows, setFollows] = useState([]);

  const [recommends, setRecommends] = useState([]);

  const fetchArticles = async () => {
    const articles = await service.getStockArticles(window.location.href.split("/")[6]);
    setArticles(articles);
  };
  const fetchFollows = async () => {
    const follows = await followService.getStockFollows(window.location.href.split("/")[6]);
    setFollows(follows);
  //  console.log(follows);
  };
  const fetchRecommends = async () => {
    const recommends = await recommendService.getStockRecommends(window.location.href.split("/")[6]);
    setRecommends(recommends);
    console.log(recommends);
  };



  useEffect(() => {
    fetchArticles();
    fetchFollows();
    fetchRecommends();
  }, []);



  const handleFollow = async () => {
    const uid = currentUser._id
    const stock = window.location.href.split("/")[6]
    console.log({ uid, stock});
    try {
      await dispatch(followService.createFollowThunk({ uid, stock}));
      
    } catch (e) {
      alert(e);
    }
   };
   const handleRecommend = async () => {
    const uid = currentUser._id
    const stock = window.location.href.split("/")[6]
    console.log({ uid, stock});
    try {
      await dispatch(recommendService.createRecommendThunk({ uid, stock}));
      
    } catch (e) {
      alert(e);
    }
   };

 return(
   <>
<br></br>
<ul className="list-group">
<li className="list-group-item">
  Stock Symbol: 
  {window.location.href.split("/")[6]}
  <br></br>
  Most Recent Stock Price: 
  {(check(stocksData.filter((item) => item.symbol === window.location.href.split("/")[6])))[0].lastPrice}
  <br></br>
  Percent Change Over Last Year: 
  {(check(stocksData.filter((item) => item.symbol === window.location.href.split("/")[6])))[0].perChange365d}%
  <br></br>
  Percent Change Over Last Day: 
  {(check(stocksData.filter((item) => item.symbol === window.location.href.split("/")[6])))[0].pChange}%
  <br></br>
  Users Following:
  {follows.length}
  <br></br>
  User Recommendations:
  {recommends.length}

</li>
   </ul>

   {currentUser && <button className="btn btn-primary mt-2"
           onClick={handleFollow}>
     Follow
   </button>}
   {currentUser && <button className="btn btn-primary mt-2"
           onClick={handleRecommend}>
     Recommend
   </button>}


   {/* <pre>{JSON.stringify(articles, null, 2)}</pre> */}
   <h2>Recent Articles:</h2>
   <ul className="list-group">
     {
       articles.map(article =>
         <ArticleItem
           key={article._id} article={article}/> ).slice(-3).reverse()
     }
     </ul>
<br></br>
   </>
 );
}
export default DetailsScreen;