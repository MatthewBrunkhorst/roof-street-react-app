import React from "react";
import ArticleList from "../articles";
import WhatsHappening from "./whats-happening";
import { AiOutlineSearch } from "react-icons/ai";
import { GoGear } from "react-icons/go";
import { useSelector } from "react-redux";
import "./index.css";
function HomeScreen() {
  let { currentUser } = useSelector((state) => state.user);
if (currentUser == null) {
  currentUser = {role: "wrong"};
}
 return(
   <>
     

<h1><center>Welcome to Roof Street, the #2 Street for Stock Market Enthusiasts!</center></h1>
<br></br>
{currentUser.role == "JOURNALIST" && <WhatsHappening/>}
{currentUser.role != "JOURNALIST" && <h1>Recent Articles</h1>}
{currentUser.role == "JOURNALIST" && <h1>Your Recent Articles<br></br><br></br></h1>}
     <ArticleList/>
   </>
 );
}
export default HomeScreen;