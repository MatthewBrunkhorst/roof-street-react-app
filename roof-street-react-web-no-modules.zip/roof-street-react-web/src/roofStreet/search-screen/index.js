import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import { register, updateUserThunk} from "../services/auth-thunks";
function SearchScreen() {
 const [query, setQuery] = useState("");

 const navigate = useNavigate();


 const handleSearch = async () => {

    
    navigate(`/RoofStreet/search/${query}`);

 };

 return (
  <div>
   <h1>Search for a Stock</h1>
   <div className="mt-2">
    <label>Stock Symbol</label>
    <input className="form-control" type="text" value={query}
     onChange={(event) => setQuery(event.target.value)}/>
   </div>

   <br></br>

   <button className="btn btn-primary mt-2"
           onClick={handleSearch}>
     Search
   </button>
  </div>
 );

}
export default SearchScreen;